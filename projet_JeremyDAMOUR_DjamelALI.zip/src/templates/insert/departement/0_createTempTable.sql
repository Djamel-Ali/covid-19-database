CREATE TEMP TABLE tempDepartement
(
    numDep CHAR(3),
    nomDep VARCHAR,
    numReg INTEGER,
    nomReg VARCHAR
);
