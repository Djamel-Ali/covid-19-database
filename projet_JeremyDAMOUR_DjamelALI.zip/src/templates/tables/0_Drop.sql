DROP TABLE IF EXISTS Sexe, Departement, Region, SexesDep, Incidence, AgesReg, audit_incid_dc_tab CASCADE;
