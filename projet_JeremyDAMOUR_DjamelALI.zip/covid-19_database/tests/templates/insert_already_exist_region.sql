INSERT INTO Region (numReg, bomReg) VALUES
(97, "Outre Mer 2")
