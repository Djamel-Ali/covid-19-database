INSERT INTO Sexe (idSexe, sexe) VALUES
(2, "masculin")