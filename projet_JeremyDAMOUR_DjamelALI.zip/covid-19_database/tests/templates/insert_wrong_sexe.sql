INSERT INTO Sexe (idSexe, sexe) VALUES
(1, "alien")