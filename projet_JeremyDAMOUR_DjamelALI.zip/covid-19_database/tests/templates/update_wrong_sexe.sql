UPDATE Sexe
SET sexe = 'masculin'
WHERE idSexe = 2