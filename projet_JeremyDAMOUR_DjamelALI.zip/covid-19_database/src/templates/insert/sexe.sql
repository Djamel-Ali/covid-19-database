INSERT INTO Sexe(idSexe, sexe) VALUES
(1, 'masculin'),
(2, 'feminin');