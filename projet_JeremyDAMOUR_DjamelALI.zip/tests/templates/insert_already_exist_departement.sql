INSERT INTO Departement VALUES
("4", "Reunion 2", 97)
