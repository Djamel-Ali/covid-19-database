INSERT INTO Region (numReg, bomReg) VALUES
(7, "new region")
